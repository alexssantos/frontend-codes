/* questao 6
Criar um componente para criação de usuário e login em aplicação(sign up/ sign in).

LOGIN
No 1o cenário, antes de estar logado, o visitante se depara com o formulário de login ou de criação de usuário.
Se for feito o login com sucesso, o componente deve levar ao cenário 2, se falhar ele deve alertar o usuário e
voltar ao início do cenário 1. Se o usuário optar por criar um usuário, o componente deve criar o registro de um
novo usuário e voltar para início do cenário 1.

LOGADO
No cenário 2, após logado, mostrar apenas um texto de logado no componente e um botão (ou link) para deslogar, retornando ao início do cenário 1.
Deve ser possível criar múltiplos usuários e, se fechada, a página não pode perder os registros de usuários  armazenados.
*/

